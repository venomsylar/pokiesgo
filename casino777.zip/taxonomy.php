<?php get_header(); ?>
    <main class="content">
        <?php echo do_shortcode('[breadcrumbs]') ?>
        <?php get_template_part('template-parts/global/constructor/constructor'); ?>
    </main>
<?php get_footer(); ?>