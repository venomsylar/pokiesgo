import 'core-js/features/promise';
import 'regenerator-runtime/runtime';
import 'js-cookie/src/js.cookie';

import './js/index';
import './styles/main.scss';