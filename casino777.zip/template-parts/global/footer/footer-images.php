<figure class="footer_images">
    <img src="<?php echo venom_get_theme_url('assets/images/approvals18.svg') ?>" alt="footer-images">
    <img src="<?php echo venom_get_theme_url('assets/images/gamecare.svg') ?>" alt="footer-images">
    <img src="<?php echo venom_get_theme_url('assets/images/dmca.svg') ?>" alt="footer-images">
    <img src="<?php echo venom_get_theme_url('assets/images/gambleavare.svg') ?>" alt="footer-images">
	<?php echo venom_get_social_media_icons_mock() ?>
</figure>