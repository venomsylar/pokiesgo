<?php
require_once __DIR__ . '/WPStructuralElements.php';
require_once __DIR__ . '/ACFRelationshipTemplateFilter.php';
require_once __DIR__ . '/CustomPostType.php';
require_once __DIR__ . '/CustomTaxonomy.php';
require_once __DIR__ . '/TaxUrlShortcutRewriter.php';
require_once __DIR__ . '/PostUrlShortcutRewriter.php';
require_once __DIR__ . '/Debug.php';
require_once __DIR__ . '/ACFMessageFilter/ACFMessageFilter.php';