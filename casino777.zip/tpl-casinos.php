<?php
/**
 * Template Name: Casinos
 */
?>

<?php get_header(); ?>
<div class="content">
    <?php echo do_shortcode('[breadcrumbs]') ?>
    <?php get_template_part('template-parts/global/constructor/constructor'); ?>
</div>
<?php get_footer(); ?>
