<?php get_header(); ?>
<div class="content">
    <?php get_template_part('template-parts/global/constructor/constructor'); ?>
</div>
<?php get_footer(); ?>